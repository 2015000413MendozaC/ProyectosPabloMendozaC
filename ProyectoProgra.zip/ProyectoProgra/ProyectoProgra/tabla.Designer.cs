﻿namespace ProyectoProgra
{
    partial class tabla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            Nombre = new DataGridViewTextBoxColumn();
            Grado = new DataGridViewTextBoxColumn();
            Seccion = new DataGridViewTextBoxColumn();
            numero = new DataGridViewTextBoxColumn();
            Matricula = new DataGridViewTextBoxColumn();
            Ciclo = new DataGridViewTextBoxColumn();
            Papa = new DataGridViewTextBoxColumn();
            Mama = new DataGridViewTextBoxColumn();
            Enfermedades = new DataGridViewTextBoxColumn();
            Promedios = new DataGridViewTextBoxColumn();
            Edad = new DataGridViewTextBoxColumn();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label11 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox11 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox12 = new TextBox();
            label12 = new Label();
            menuStrip1 = new MenuStrip();
            menúToolStripMenuItem = new ToolStripMenuItem();
            creditosToolStripMenuItem = new ToolStripMenuItem();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Nombre, Grado, Seccion, numero, Matricula, Ciclo, Papa, Mama, Enfermedades, Promedios, Edad });
            dataGridView1.Location = new Point(12, 41);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(523, 412);
            dataGridView1.TabIndex = 0;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.Name = "Nombre";
            // 
            // Grado
            // 
            Grado.HeaderText = "Grado";
            Grado.Name = "Grado";
            // 
            // Seccion
            // 
            Seccion.HeaderText = "Seccion";
            Seccion.Name = "Seccion";
            // 
            // numero
            // 
            numero.HeaderText = "Numero Telefonico";
            numero.Name = "numero";
            // 
            // Matricula
            // 
            Matricula.HeaderText = "Numero de Matricula";
            Matricula.Name = "Matricula";
            // 
            // Ciclo
            // 
            Ciclo.HeaderText = "Ciclo Academico Actual";
            Ciclo.Name = "Ciclo";
            // 
            // Papa
            // 
            Papa.HeaderText = "Numero de Papá";
            Papa.Name = "Papa";
            // 
            // Mama
            // 
            Mama.HeaderText = "Numero de Mamá";
            Mama.Name = "Mama";
            // 
            // Enfermedades
            // 
            Enfermedades.HeaderText = "Posibles Enfermedades";
            Enfermedades.Name = "Enfermedades";
            // 
            // Promedios
            // 
            Promedios.HeaderText = "Promedio";
            Promedios.Name = "Promedios";
            // 
            // Edad
            // 
            Edad.HeaderText = "Edad";
            Edad.Name = "Edad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(566, 60);
            label2.Name = "label2";
            label2.Size = new Size(71, 21);
            label2.TabIndex = 5;
            label2.Text = "Nombre:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(566, 92);
            label1.Name = "label1";
            label1.Size = new Size(56, 21);
            label1.TabIndex = 6;
            label1.Text = "Grado:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(566, 122);
            label3.Name = "label3";
            label3.Size = new Size(66, 21);
            label3.TabIndex = 7;
            label3.Text = "Seccion:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(566, 153);
            label4.Name = "label4";
            label4.Size = new Size(71, 21);
            label4.TabIndex = 8;
            label4.Text = "Numero:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(566, 187);
            label5.Name = "label5";
            label5.Size = new Size(78, 21);
            label5.TabIndex = 9;
            label5.Text = "Matricula:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(566, 219);
            label6.Name = "label6";
            label6.Size = new Size(47, 21);
            label6.TabIndex = 10;
            label6.Text = "Ciclo:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(566, 250);
            label7.Name = "label7";
            label7.Size = new Size(129, 21);
            label7.TabIndex = 11;
            label7.Text = "Numero de Papá:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(566, 285);
            label8.Name = "label8";
            label8.Size = new Size(140, 21);
            label8.TabIndex = 12;
            label8.Text = "Numero de Mamá:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(566, 319);
            label9.Name = "label9";
            label9.Size = new Size(112, 21);
            label9.TabIndex = 13;
            label9.Text = "Enfermedades:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(566, 383);
            label11.Name = "label11";
            label11.Size = new Size(47, 21);
            label11.TabIndex = 15;
            label11.Text = "Edad:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(783, 58);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(176, 23);
            textBox1.TabIndex = 16;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(783, 90);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(176, 23);
            textBox2.TabIndex = 17;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(783, 120);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(176, 23);
            textBox3.TabIndex = 18;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(783, 151);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(176, 23);
            textBox4.TabIndex = 19;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(783, 185);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(176, 23);
            textBox5.TabIndex = 20;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(783, 217);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(176, 23);
            textBox6.TabIndex = 21;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(783, 248);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(176, 23);
            textBox7.TabIndex = 22;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(783, 283);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(176, 23);
            textBox8.TabIndex = 23;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(783, 317);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(176, 23);
            textBox9.TabIndex = 24;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(783, 381);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(176, 23);
            textBox11.TabIndex = 26;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(714, 417);
            button1.Name = "button1";
            button1.Size = new Size(98, 36);
            button1.TabIndex = 27;
            button1.Text = "Guardar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(24, 470);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 28;
            button2.Text = "Editar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(142, 470);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 29;
            button3.Text = "Eliminar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(783, 352);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(176, 23);
            textBox12.TabIndex = 30;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(566, 352);
            label12.Name = "label12";
            label12.Size = new Size(81, 21);
            label12.TabIndex = 31;
            label12.Text = "Promedio:";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menúToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1072, 24);
            menuStrip1.TabIndex = 32;
            menuStrip1.Text = "menuStrip1";
            // 
            // menúToolStripMenuItem
            // 
            menúToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { creditosToolStripMenuItem });
            menúToolStripMenuItem.Name = "menúToolStripMenuItem";
            menúToolStripMenuItem.Size = new Size(50, 20);
            menúToolStripMenuItem.Text = "Menú";
            // 
            // creditosToolStripMenuItem
            // 
            creditosToolStripMenuItem.Name = "creditosToolStripMenuItem";
            creditosToolStripMenuItem.Size = new Size(180, 22);
            creditosToolStripMenuItem.Text = "Creditos";
            creditosToolStripMenuItem.Click += creditosToolStripMenuItem_Click;
            // 
            // button4
            // 
            button4.Location = new Point(266, 470);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 33;
            button4.Text = "Salir";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // tabla
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1072, 505);
            Controls.Add(button4);
            Controls.Add(label12);
            Controls.Add(textBox12);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox11);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label11);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "tabla";
            Text = "tabla";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Enferedades;
        private DataGridViewTextBoxColumn Promedio;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox12;
        private Label label12;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Grado;
        private DataGridViewTextBoxColumn Seccion;
        private DataGridViewTextBoxColumn numero;
        private DataGridViewTextBoxColumn Matricula;
        private DataGridViewTextBoxColumn Ciclo;
        private DataGridViewTextBoxColumn Papa;
        private DataGridViewTextBoxColumn Mama;
        private DataGridViewTextBoxColumn Enfermedades;
        private DataGridViewTextBoxColumn Promedios;
        private DataGridViewTextBoxColumn Edad;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menúToolStripMenuItem;
        private ToolStripMenuItem creditosToolStripMenuItem;
        private Button button4;
    }
}