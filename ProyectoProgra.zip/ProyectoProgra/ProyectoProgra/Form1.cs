namespace ProyectoProgra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = "Pablo Mendoza";
            string contrase�a = "El clan de mamasita31";

            if (textBox2.Text == usuario && textBox1.Text == contrase�a)
            {
                tabla lacosaesa = new tabla();
                lacosaesa.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o Contrase�a Inconrrecta");
            }
        }
    }
}
