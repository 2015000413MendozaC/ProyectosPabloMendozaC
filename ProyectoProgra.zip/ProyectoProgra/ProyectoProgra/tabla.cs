﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ProyectoProgra
{
    public partial class tabla : Form
    {
        public tabla()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(
                textBox1.Text,
                textBox2.Text,
                textBox3.Text,
                textBox4.Text,
                textBox5.Text,
                textBox6.Text,
                textBox7.Text,
                textBox8.Text,
                textBox9.Text,
                textBox12.Text,
                textBox11.Text
                );

            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox12.Text = "";
            textBox11.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                DataGridViewRow fila = dataGridView1.CurrentRow;
                fila.Cells["Nombre"].Value = textBox1.Text;
                fila.Cells["Grado"].Value = textBox2.Text;
                fila.Cells["Seccion"].Value = textBox3.Text;
                fila.Cells["Numero"].Value = textBox4.Text;
                fila.Cells["Matricula"].Value = textBox5.Text;
                fila.Cells["Ciclo"].Value = textBox6.Text;
                fila.Cells["Papa"].Value = textBox7.Text;
                fila.Cells["Mama"].Value = textBox8.Text;
                fila.Cells["Enfermedades"].Value = textBox9.Text;
                fila.Cells["Promedios"].Value = textBox12.Text;
                fila.Cells["Edad"].Value = textBox11.Text;

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void creditosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            creditos esacosa = new creditos();
            esacosa.Show();
            this.Hide();
        }
    }
}
